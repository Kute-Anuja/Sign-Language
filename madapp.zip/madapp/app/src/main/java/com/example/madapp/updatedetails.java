package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.jar.Attributes;

public class updatedetails extends AppCompatActivity {
    ImageView back2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatedetails);
        EditText e1 = (EditText) findViewById(R.id.editTextTextPersonName);
        EditText e2 = (EditText) findViewById(R.id.editTextPhone);
        EditText e3 = (EditText) findViewById(R.id.editTextTextEmailAddress);
        TextView t1 = (TextView) findViewById(R.id.textView);
        TextView t2 = (TextView) findViewById(R.id.textView2);
        TextView t3 = (TextView) findViewById(R.id.textView3);
        Button b1 = (Button) findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String editTextTextPersonName = e1.getText().toString();
                String editTextPhone = e2.getText().toString();
                String editTextTextEmailAdress = e3.getText().toString();
                Intent i = new Intent(updatedetails.this, setting.class);
                i.putExtra("NAME",editTextTextPersonName);
                i.putExtra("PHONE NO.",editTextPhone);
                i.putExtra("EMAIL ID",editTextTextEmailAdress);
                startActivity(i);

                i=getIntent();
                String NAME =i.getStringExtra("NAME");
                t1.setText(NAME);
                String PHONENO =i.getStringExtra("PHONE NO.");
                t2.setText(PHONENO);
                String EMAILID =i.getStringExtra("EMAIL ID");
                t3.setText(EMAILID);
                Toast.makeText(updatedetails.this, "Profile Updated",Toast.LENGTH_SHORT).show();

            }
        });
        back2=findViewById(R.id.back2);
        back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent( updatedetails.this, setting.class);
                startActivity(intent);
            }
        });
    }
}