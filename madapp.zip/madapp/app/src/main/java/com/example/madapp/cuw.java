package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

public class cuw extends AppCompatActivity {
ImageView baccuw;
TextView hello;
    TextView ty;
    TextView help;
    TextView plz;
    TextView morn;
    TextView again;
    TextView wc;
    TextView relax;
    TextView frnd;
    TextView kind;
    TextView quiet;
    TextView funny;
    TextView sick;
    TextView best;
    TextView love;
    TextView party;
    TextView imp;
    TextView holiday;
    TextView agree;
    TextView happy;
    TextView bro;
    TextView sis;
    TextView easy;
    TextView fam;
    TextView slow;
    TextView need;
    TextView neww;
    TextView money;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuw);
        baccuw=findViewById(R.id.baccuw);
        baccuw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, learn.class);
                startActivity(i);
            }
        });
        hello=findViewById(R.id.hello);
        hello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, hello.class);
                startActivity(i);
            }
        });
        ty=findViewById(R.id.ty);
        ty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, thankyou.class);
                startActivity(i);
            }
        });
        plz=findViewById(R.id.plz);
        plz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, please.class);
                startActivity(i);
            }
        });
        morn=findViewById(R.id.morn);
        morn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, morning.class);
                startActivity(i);
            }
        });
        help=findViewById(R.id.help);
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, helppp.class);
                startActivity(i);
            }
        });
        wc=findViewById(R.id.wc);
        wc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, welcome.class);
                startActivity(i);
            }
        });
        again=findViewById(R.id.again);
        again.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, again.class);
                startActivity(i);
            }
        });
        relax=findViewById(R.id.relax);
        relax.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, relax.class);
                startActivity(i);
            }
        });
        frnd=findViewById(R.id.frnd);
        frnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, friend.class);
                startActivity(i);
            }
        });
        kind=findViewById(R.id.kind);
        kind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, kind.class);
                startActivity(i);
            }
        });
        quiet=findViewById(R.id.quiet);
        quiet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, quiet.class);
                startActivity(i);
            }
        });
        funny=findViewById(R.id.funny);
        funny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, funny.class);
                startActivity(i);
            }
        });
        sick=findViewById(R.id.sick);
        sick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, sick.class);
                startActivity(i);
            }
        });
        best=findViewById(R.id.best);
        best.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, best.class);
                startActivity(i);
            }
        });
        love=findViewById(R.id.love);
        love.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, love.class);
                startActivity(i);
            }
        });
       party=findViewById(R.id.party);
        party.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, party.class);
                startActivity(i);
            }
        });
        imp=findViewById(R.id.imp);
       imp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, important.class);
                startActivity(i);
            }
        });
        holiday=findViewById(R.id.holiday);
        holiday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, holiday.class);
                startActivity(i);
            }
        });
        agree=findViewById(R.id.agree);
        agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, agree.class);
                startActivity(i);
            }
        });
        bro=findViewById(R.id.bro);
        bro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, brother.class);
                startActivity(i);
            }
        });
        sis=findViewById(R.id.sis);
        sis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, sister.class);
                startActivity(i);
            }
        });
        easy=findViewById(R.id.easy);
        easy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, easy.class);
                startActivity(i);
            }
        });
        fam=findViewById(R.id.fam);
        fam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, family.class);
                startActivity(i);
            }
        });
        slow=findViewById(R.id.slow);
        slow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, slow.class);
                startActivity(i);
            }
        });
        need=findViewById(R.id.need);
        need.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, need.class);
                startActivity(i);
            }
        });
        neww=findViewById(R.id.neww);
        neww.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, neww.class);
                startActivity(i);
            }
        });
        money=findViewById(R.id.money);
        money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, money.class);
                startActivity(i);
            }
        });
        happy=findViewById(R.id.happy);
        happy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(cuw.this, happy.class);
                startActivity(i);
            }
        });

    }
}