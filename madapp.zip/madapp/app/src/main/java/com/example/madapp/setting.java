package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class setting extends AppCompatActivity {
    SwitchCompat switchMode;
    boolean nightmode;
    SharedPreferences sharedPreferences;
    Intent intent;
    ImageView arrow;
    ImageView arrow2;
    ImageView arrow1;
    ImageView back;
    ImageView arrow3;
    Button edit;
    SharedPreferences.Editor editor;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        switchMode = findViewById(R.id.switchmo);
        sharedPreferences = getSharedPreferences("Mode", Context.MODE_PRIVATE);
        nightmode = sharedPreferences.getBoolean("nightMode", false);
        if(nightmode){
            switchMode.setChecked(true);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
        switchMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nightmode){
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editor = sharedPreferences.edit();
                    editor.putBoolean("nightMode", false);
                }
                else{
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    editor = sharedPreferences.edit();
                    editor.putBoolean("nightMode", true);
                }
                editor.apply();
            }
        });
        arrow=findViewById(R.id.arrow);
        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(setting.this, login.class);
                startActivity(intent);
                finish();
                Toast.makeText(setting.this, "Successfully logout",Toast.LENGTH_SHORT).show();
            }
        });

        back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent( setting.this, first.class);
                startActivity(intent);
            }
        });
        arrow2=findViewById(R.id.arrow2);
        arrow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(setting.this,contact_details.class);
                startActivity(intent1);
            }
        });
        arrow1=findViewById(R.id.arrow1);
        arrow1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(setting.this, help.class);
                startActivity(intent1);
            }
        });
        arrow3=findViewById(R.id.arrow3);
        arrow3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(setting.this, changepassword.class);
                startActivity(i);
            }
        });
        edit=findViewById(R.id.edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1= new Intent(setting.this, updatedetails.class);
                startActivity(i1);
            }
        });
    }
}