package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.function.IntFunction;

public class first extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        ImageView lines3=findViewById(R.id.lines3);
        lines3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new
                        Intent(first.this,setting.class);
                startActivity(i);
            }
        });
        TextView learn=findViewById(R.id.learn);
        learn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new
                        Intent(first.this, learn.class);
                startActivity(i);
            }
        });
        TextView translate=findViewById(R.id.translate);
        translate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new
                        Intent(first.this, MainActivity2.class);
                startActivity(i);
            }
        });
    }
}
