package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Button;

public class learn extends AppCompatActivity {
    ImageView back4;
    Button bcuw;
    Button alpha;
    Button num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn);
        back4=findViewById(R.id.back4);
        back4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent( learn.this, first.class);
                startActivity(intent);
            }
        });
        alpha=findViewById(R.id.alpha);
        alpha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(learn.this, alphabet.class);
                startActivity(i);
            }
        });
        bcuw=findViewById(R.id.bcuw);
        bcuw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(learn.this, cuw.class);
                startActivity(i);
            }
        });
        num=findViewById(R.id.num);
        num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(learn.this, numbers.class);
                startActivity(i);
            }
        });
    }
}