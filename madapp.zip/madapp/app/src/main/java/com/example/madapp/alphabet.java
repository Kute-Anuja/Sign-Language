package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class alphabet extends AppCompatActivity {
    Intent intent;
    ImageView back8;
    TextView a;
    TextView b;
    TextView c;
    TextView d;
    TextView e;
    TextView f;
    TextView g;
    TextView h;
    TextView i;
    TextView j;
    TextView k;
    TextView l;
    TextView m;
    TextView n;
    TextView o;
    TextView p;
    TextView q;
    TextView r;
    TextView s;
    TextView t;
    TextView u;
    TextView v;
    TextView w;
    TextView x;
    TextView y;
    TextView z;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alphabet);
        back8=findViewById(R.id.back8);
        back8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, learn.class);
                startActivity(i);
            }
        });
        a=findViewById(R.id.a);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, a.class);
                startActivity(i);
            }
        });
        b=findViewById(R.id.b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, b.class);
                startActivity(i);
            }
        });
        c=findViewById(R.id.c);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, c.class);
                startActivity(i);
            }
        });
        d=findViewById(R.id.d);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, d.class);
                startActivity(i);
            }
        });
        e=findViewById(R.id.e);
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, e.class);
                startActivity(i);
            }
        });
        f=findViewById(R.id.f);
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, f.class);
                startActivity(i);
            }
        });
        g=findViewById(R.id.g);
        g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, g.class);
                startActivity(i);
            }
        });
        h=findViewById(R.id.h);
        h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, h.class);
                startActivity(i);
            }
        });
        i=findViewById(R.id.i);
        i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in= new Intent(alphabet.this, i.class);
                startActivity(in);
            }
        });
        j=findViewById(R.id.j);
        j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, j.class);
                startActivity(i);
            }
        });
        k=findViewById(R.id.k);
        k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, k.class);
                startActivity(i);
            }
        });
        l=findViewById(R.id.l);
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, l.class);
                startActivity(i);
            }
        });
        m=findViewById(R.id.m);
        m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, m.class);
                startActivity(i);
            }
        });
        n=findViewById(R.id.n);
        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, n.class);
                startActivity(i);
            }
        });
        o=findViewById(R.id.o);
        o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, o.class);
                startActivity(i);
            }
        });
        p=findViewById(R.id.p);
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, p.class);
                startActivity(i);
            }
        });
        q=findViewById(R.id.q);
        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, q.class);
                startActivity(i);
            }
        });
        r=findViewById(R.id.r);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, r.class);
                startActivity(i);
            }
        });
        s=findViewById(R.id.s);
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, s.class);
                startActivity(i);
            }
        });
        t=findViewById(R.id.t);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, t.class);
                startActivity(i);
            }
        });
        u=findViewById(R.id.u);
        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, u.class);
                startActivity(i);
            }
        });
        v=findViewById(R.id.v);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, v.class);
                startActivity(i);
            }
        });
        w=findViewById(R.id.w);
        w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, w.class);
                startActivity(i);
            }
        });
        x=findViewById(R.id.x);
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, x.class);
                startActivity(i);
            }
        });
        y=findViewById(R.id.y);
        y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, y.class);
                startActivity(i);
            }
        });
        z=findViewById(R.id.z);
        z.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(alphabet.this, z.class);
                startActivity(i);
            }
        });

    }
}