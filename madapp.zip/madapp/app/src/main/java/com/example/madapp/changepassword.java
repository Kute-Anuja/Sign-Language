package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class changepassword extends AppCompatActivity {
    ImageView back5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepassword);
        TextView t1 = (TextView) findViewById(R.id.textView);
        TextView t2 = (TextView) findViewById(R.id.textView2);
        TextView t3 = (TextView) findViewById(R.id.textView3);
        TextView t4 = (TextView) findViewById(R.id.textView4);
        EditText e1 = (EditText) findViewById(R.id.editTextTextPersonName);
        EditText e2 = (EditText) findViewById(R.id.editTextTextPersonName2);
        EditText e3 = (EditText) findViewById(R.id.editTextTextPersonName3);
        Button b1 = (Button) findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Enteryourpassword = e1.getText().toString();
                String Enteryoupassword = e2.getText().toString();
                Enteryourpassword = e3.getText().toString();
                Intent i = new Intent(changepassword.this, setting.class);
                i.putExtra("Old password", Enteryourpassword);
                i.putExtra("New password", Enteryourpassword);
                i.putExtra("Confirm password", Enteryourpassword);
                startActivity(i);

                i = getIntent();
                String Changepassword = i.getStringExtra(" Changepassword");
                t1.setText(Changepassword);
                Enteryourpassword = i.getStringExtra("Old password");
                t2.setText(Enteryourpassword);
                Enteryourpassword = i.getStringExtra("New password");
                t3.setText(Enteryourpassword);
                Enteryourpassword = i.getStringExtra("Confirm password");
                t4.setText(Enteryourpassword);
                Toast.makeText(changepassword.this, "Password changed Successfully",Toast.LENGTH_SHORT).show();

            }
        });
        back5=findViewById(R.id.back5);
        back5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent( changepassword.this, setting.class);
                startActivity(intent);
            }
        });

    }
}