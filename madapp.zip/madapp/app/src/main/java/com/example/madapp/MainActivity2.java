package com.example.madapp;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        EditText editText = findViewById(R.id.editText);

        // Set a TextWatcher on the EditText
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {
                // Not needed for this example
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                // Call a function to change the image based on the input
                changeImage(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Not needed for this example
            }
        });
    }

    private void changeImage(String inputText) {
        ImageView imageView = findViewById(R.id.imageView);

        // Check the input text and set the corresponding image
        switch (inputText.toLowerCase()) {
            case "hello":
                imageView.setImageResource(R.drawable.hello);
                break;
            case "deaf":
                imageView.setImageResource(R.drawable.deaf);
                break;
            case "kind":
                imageView.setImageResource(R.drawable.kind);
                break;
            case "morning":
                imageView.setImageResource(R.drawable.morning);
                break;
            case "again":
                imageView.setImageResource(R.drawable.again);
                break;
            case "holiday":
                imageView.setImageResource(R.drawable.holiday);
                break;
            case "love":
                imageView.setImageResource(R.drawable.love);
                break;
            case "help":
                imageView.setImageResource(R.drawable.help);
                break;
            case "money":
                imageView.setImageResource(R.drawable.money);
                break;
            case "need":
                imageView.setImageResource(R.drawable.need);
                break;
            case "quiet":
                imageView.setImageResource(R.drawable.quiet);
                break;
            case "party":
                imageView.setImageResource(R.drawable.party);
                break;

            case "one":
                imageView.setImageResource(R.drawable.one);
                break;
            case "two":
                imageView.setImageResource(R.drawable.two);
                break;
            case "three":
                imageView.setImageResource(R.drawable.tree);
                break;
            case "zero":
                imageView.setImageResource(R.drawable.zero);
                break;
                case "four":
                imageView.setImageResource(R.drawable.four);
                break;
            case "five":
                imageView.setImageResource(R.drawable.five);
                break;
            case "six":
                imageView.setImageResource(R.drawable.six);
                break;
            case "seven":
                imageView.setImageResource(R.drawable.seven);
                break;
            case "eight":
                imageView.setImageResource(R.drawable.eight);
                break;
            case "nine":
                imageView.setImageResource(R.drawable.nine);
                break;
                case "thank you":
                imageView.setImageResource(R.drawable.thankyou);
                break;
                case "agree":
                imageView.setImageResource(R.drawable.agree);
                break;
            case "best":
                imageView.setImageResource(R.drawable.best);
                break;
            case "brother":
                imageView.setImageResource(R.drawable.brother);
                break;
            case "sister":
                imageView.setImageResource(R.drawable.sister);
                break;
            case "easy":
                imageView.setImageResource(R.drawable.easy);
                break;
            case "happy":
                imageView.setImageResource(R.drawable.happy);
                break;
            case "friends":
                imageView.setImageResource(R.drawable.friends);
                break;
            case "funny":
                imageView.setImageResource(R.drawable.funny);
                break;
            case "family":
                imageView.setImageResource(R.drawable.family);
                break;
            case "boy":
                imageView.setImageResource(R.drawable.boy);
                break;
            case "equality":
                imageView.setImageResource(R.drawable.equality);
                break;
            case "fast":
                imageView.setImageResource(R.drawable.fast);
                break;
            case "gift":
                imageView.setImageResource(R.drawable.gift);
                break;
            case "important":
                imageView.setImageResource(R.drawable.important);
                break;
            case "mother":
                imageView.setImageResource(R.drawable.mun);
                break;
            case "mom":
                imageView.setImageResource(R.drawable.mun);
                break;
            case "meet":
                imageView.setImageResource(R.drawable.meet);
                break;
            case "new":
                imageView.setImageResource(R.drawable.neww);
                break;
            case "nice":
                imageView.setImageResource(R.drawable.nice);
                break;
            case "office":
                imageView.setImageResource(R.drawable.office);
                break;
            case "please":
                imageView.setImageResource(R.drawable.please);
                break;
            case "problem":
                imageView.setImageResource(R.drawable.problem);
                break;
            case "sick":
                imageView.setImageResource(R.drawable.sick);
                break;
            case "slow":
                imageView.setImageResource(R.drawable.slow);
                break;
            case "tea":
                imageView.setImageResource(R.drawable.tea);
                break;
            case "want":
                imageView.setImageResource(R.drawable.want);
                break;
            case "woman":
                imageView.setImageResource(R.drawable.woman);
                break;
            case "you":
                imageView.setImageResource(R.drawable.you);
                break;
            case "welcome":
                imageView.setImageResource(R.drawable.welcome);
                break;

            // Add more cases for other texts and corresponding images
            default:
                imageView.setImageResource(R.drawable.default_image);
                break;
        }
    }
}