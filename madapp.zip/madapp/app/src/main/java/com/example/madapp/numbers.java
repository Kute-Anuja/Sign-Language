package com.example.madapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class numbers extends AppCompatActivity {
ImageView backnum;
TextView zero;
    TextView one;
    TextView two;
    TextView three;
    TextView four;
    TextView five;
    TextView six;
    TextView seven;
    TextView eight;
    TextView nine;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers);
        backnum=findViewById(R.id.backnum);
        backnum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, learn.class);
                startActivity(i);
            }
        });
        one=findViewById(R.id.one);
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, one.class);
                startActivity(i);
            }
        });
       two=findViewById(R.id.two);
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, two.class);
                startActivity(i);
            }
        });
        zero=findViewById(R.id.zero);
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, zero.class);
                startActivity(i);
            }
        });
        three=findViewById(R.id.three);
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, three.class);
                startActivity(i);
            }
        });
        four=findViewById(R.id.four);
       four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, four.class);
                startActivity(i);
            }
        });
       five=findViewById(R.id.five);
       five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, five.class);
                startActivity(i);
            }
        });
        six=findViewById(R.id.six);
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, six.class);
                startActivity(i);
            }
        });
        seven=findViewById(R.id.seven);
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, seven.class);
                startActivity(i);
            }
        });
        eight=findViewById(R.id.eight);
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, eight.class);
                startActivity(i);
            }
        });
        nine=findViewById(R.id.nine);
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(numbers.this, nine.class);
                startActivity(i);
            }
        });
    }
}